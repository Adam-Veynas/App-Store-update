package kz.springboot.springbootdemo.entities;

public enum LocalType {
    KZ,RU,EN

}
